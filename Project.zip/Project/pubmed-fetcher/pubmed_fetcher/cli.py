"""Command-line interface for PubMed Fetcher."""

import argparse
import sys
from pathlib import Path
from typing import Optional

from .fetcher import PubMedFetcher


def create_parser() -> argparse.ArgumentParser:
    """Create and configure the argument parser."""
    parser = argparse.ArgumentParser(
        description="Fetch PubMed papers and identify non-academic authors from biotech/pharma companies",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s "cancer immunotherapy"
  %(prog)s "CRISPR gene editing" --file results.csv
  %(prog)s "mRNA vaccine" --debug --file vaccine_papers.csv
        """
    )
    
    parser.add_argument(
        "query",
        help="Search query for PubMed papers"
    )
    
    parser.add_argument(
        "--file", "-f",
        type=str,
        help="Output CSV file path (default: papers_with_non_academic_authors.csv)"
    )
    
    parser.add_argument(
        "--debug", "-d",
        action="store_true",
        help="Enable debug logging"
    )
    
    parser.add_argument(
        "--max-results", "-m",
        type=int,
        default=100,
        help="Maximum number of papers to process (default: 100)"
    )
    
    return parser


def main(args: Optional[list] = None) -> int:
    """Main entry point for the CLI.
    
    Args:
        args: Command line arguments (defaults to sys.argv[1:])
        
    Returns:
        Exit code (0 for success, 1 for error)
    """
    parser = create_parser()
    parsed_args = parser.parse_args(args)
    
    try:
        # Initialize the fetcher
        fetcher = PubMedFetcher(debug=parsed_args.debug)
        
        # Fetch papers with non-academic authors
        papers = fetcher.fetch_papers_with_non_academic_authors(
            query=parsed_args.query,
            max_results=parsed_args.max_results
        )
        
        if not papers:
            print("No papers found with non-academic authors.")
            return 0
        
        # Determine output file
        if parsed_args.file:
            output_file = parsed_args.file
        else:
            output_file = "papers_with_non_academic_authors.csv"
        
        # Export to CSV
        fetcher.export_to_csv(papers, output_file)
        
        print(f"Successfully exported {len(papers)} papers to {output_file}")
        print(f"Query: {parsed_args.query}")
        print(f"Papers found: {len(papers)}")
        
        return 0
        
    except KeyboardInterrupt:
        print("\nOperation cancelled by user.")
        return 1
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        if parsed_args.debug:
            import traceback
            traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main()) 