"""PubMed Fetcher - A tool to fetch PubMed papers and identify non-academic authors."""

__version__ = "0.1.0"
__author__ = "Your Name"
__email__ = "your.email@example.com"

from .fetcher import PubMedFetcher
from .models import Paper, Author, Affiliation

__all__ = ["PubMedFetcher", "Paper", "Author", "Affiliation"] 