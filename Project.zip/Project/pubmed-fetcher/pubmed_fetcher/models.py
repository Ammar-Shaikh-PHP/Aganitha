"""Data models for PubMed papers, authors, and affiliations."""

from dataclasses import dataclass
from typing import List, Optional, Set
from datetime import datetime


@dataclass
class Affiliation:
    """Represents an author's institutional affiliation."""
    
    name: str
    """The name of the institution/company."""
    
    is_academic: bool
    """Whether this is an academic institution."""
    
    is_biotech_pharma: bool
    """Whether this is a biotech or pharmaceutical company."""
    
    def __post_init__(self) -> None:
        """Validate the affiliation data."""
        if not self.name.strip():
            raise ValueError("Affiliation name cannot be empty")


@dataclass
class Author:
    """Represents an author of a PubMed paper."""
    
    name: str
    """The author's name."""
    
    email: Optional[str]
    """The author's email address, if available."""
    
    affiliations: List[Affiliation]
    """List of the author's institutional affiliations."""
    
    is_corresponding: bool
    """Whether this author is the corresponding author."""
    
    def __post_init__(self) -> None:
        """Validate the author data."""
        if not self.name.strip():
            raise ValueError("Author name cannot be empty")
    
    @property
    def has_non_academic_affiliation(self) -> bool:
        """Check if the author has any non-academic affiliations."""
        return any(not aff.is_academic for aff in self.affiliations)
    
    @property
    def has_biotech_pharma_affiliation(self) -> bool:
        """Check if the author has any biotech/pharma company affiliations."""
        return any(aff.is_biotech_pharma for aff in self.affiliations)
    
    @property
    def non_academic_affiliations(self) -> List[Affiliation]:
        """Get all non-academic affiliations."""
        return [aff for aff in self.affiliations if not aff.is_academic]
    
    @property
    def biotech_pharma_affiliations(self) -> List[Affiliation]:
        """Get all biotech/pharma company affiliations."""
        return [aff for aff in self.affiliations if aff.is_biotech_pharma]


@dataclass
class Paper:
    """Represents a PubMed paper."""
    
    pubmed_id: str
    """The PubMed ID of the paper."""
    
    title: str
    """The title of the paper."""
    
    publication_date: datetime
    """The publication date of the paper."""
    
    authors: List[Author]
    """List of authors of the paper."""
    
    def __post_init__(self) -> None:
        """Validate the paper data."""
        if not self.pubmed_id.strip():
            raise ValueError("PubMed ID cannot be empty")
        if not self.title.strip():
            raise ValueError("Title cannot be empty")
    
    @property
    def has_non_academic_authors(self) -> bool:
        """Check if the paper has any non-academic authors."""
        return any(author.has_non_academic_affiliation for author in self.authors)
    
    @property
    def has_biotech_pharma_authors(self) -> bool:
        """Check if the paper has any authors from biotech/pharma companies."""
        return any(author.has_biotech_pharma_affiliation for author in self.authors)
    
    @property
    def non_academic_authors(self) -> List[Author]:
        """Get all non-academic authors."""
        return [author for author in self.authors if author.has_non_academic_affiliation]
    
    @property
    def biotech_pharma_authors(self) -> List[Author]:
        """Get all authors from biotech/pharma companies."""
        return [author for author in self.authors if author.has_biotech_pharma_affiliation]
    
    @property
    def corresponding_author(self) -> Optional[Author]:
        """Get the corresponding author, if any."""
        for author in self.authors:
            if author.is_corresponding:
                return author
        return None
    
    @property
    def corresponding_author_email(self) -> Optional[str]:
        """Get the corresponding author's email, if available."""
        corresponding = self.corresponding_author
        return corresponding.email if corresponding else None 