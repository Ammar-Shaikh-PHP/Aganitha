"""PubMed Fetcher - Main module for fetching and processing PubMed papers."""

import logging
import re
import time
from typing import List, Optional, Dict, Any, Union
from datetime import datetime
import requests
from bs4 import BeautifulSoup, Tag

from .models import Paper, Author, Affiliation


class PubMedFetcher:
    """Fetches PubMed papers and identifies non-academic authors from biotech/pharma companies."""
    
    # PubMed E-utilities base URL
    BASE_URL = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils"
    
    # Common academic institution keywords
    ACADEMIC_KEYWORDS = {
        "university", "college", "institute", "school", "academy", "medical center",
        "hospital", "clinic", "research center", "laboratory", "department",
        "faculty", "school of medicine", "medical school", "health sciences"
    }
    
    # Biotech/pharma company keywords
    BIOTECH_PHARMA_KEYWORDS = {
        "pharmaceutical", "biotech", "biotechnology", "pharma", "drug", "therapeutics",
        "genetics", "genomics", "biopharma", "biopharmaceutical", "medicinal",
        "therapeutic", "clinical", "biomedical", "molecular", "cell therapy",
        "gene therapy", "immunotherapy", "oncology", "cancer", "vaccine"
    }
    
    def __init__(self, debug: bool = False) -> None:
        """Initialize the PubMed fetcher.
        
        Args:
            debug: Enable debug logging if True
        """
        self.debug = debug
        self.logger = self._setup_logging()
        
    def _setup_logging(self) -> logging.Logger:
        """Set up logging configuration."""
        logger = logging.getLogger(__name__)
        if not logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            )
            handler.setFormatter(formatter)
            logger.addHandler(handler)
        
        logger.setLevel(logging.DEBUG if self.debug else logging.INFO)
        return logger
    
    def search_papers(self, query: str, max_results: int = 100) -> List[str]:
        """Search for papers using PubMed E-utilities.
        
        Args:
            query: Search query string
            max_results: Maximum number of results to return
            
        Returns:
            List of PubMed IDs
        """
        self.logger.info(f"Searching PubMed for: {query}")
        
        # Search for papers
        search_url = f"{self.BASE_URL}/esearch.fcgi"
        params = {
            "db": "pubmed",
            "term": query,
            "retmax": max_results,
            "retmode": "json",
            "sort": "relevance"
        }
        
        try:
            response = requests.get(search_url, params=params)
            response.raise_for_status()
            data = response.json()
            
            if "esearchresult" not in data:
                self.logger.error("Invalid response from PubMed API")
                return []
            
            id_list = data["esearchresult"].get("idlist", [])
            self.logger.info(f"Found {len(id_list)} papers")
            return id_list
            
        except requests.RequestException as e:
            self.logger.error(f"Error searching PubMed: {e}")
            return []
        except ValueError as e:
            self.logger.error(f"Error parsing JSON response: {e}")
            return []
    
    def fetch_paper_details(self, pubmed_id: str) -> Optional[Paper]:
        """Fetch detailed information for a single paper.
        
        Args:
            pubmed_id: PubMed ID of the paper
            
        Returns:
            Paper object with details, or None if failed
        """
        self.logger.debug(f"Fetching details for PMID: {pubmed_id}")
        
        # Fetch paper details
        fetch_url = f"{self.BASE_URL}/efetch.fcgi"
        params = {
            "db": "pubmed",
            "id": pubmed_id,
            "retmode": "xml"
        }
        
        try:
            response = requests.get(fetch_url, params=params)
            response.raise_for_status()
            
            # Parse XML response
            soup = BeautifulSoup(response.content, "html.parser")
            article = soup.find("pubmedarticle")
            
            if not article or not isinstance(article, Tag):
                self.logger.warning(f"No article found for PMID: {pubmed_id}")
                return None
            
            # Extract paper information
            title = self._extract_title(article)
            publication_date = self._extract_publication_date(article)
            authors = self._extract_authors(article)
            
            if not title:
                self.logger.warning(f"No title found for PMID: {pubmed_id}")
                return None
            
            return Paper(
                pubmed_id=pubmed_id,
                title=title,
                publication_date=publication_date,
                authors=authors
            )
            
        except requests.RequestException as e:
            self.logger.error(f"Error fetching paper {pubmed_id}: {e}")
            return None
        except Exception as e:
            self.logger.error(f"Error processing paper {pubmed_id}: {e}")
            return None
    
    def _extract_title(self, article: Tag) -> str:
        """Extract the title from the article XML."""
        title_elem = article.find("articletitle")
        if title_elem:
            return title_elem.get_text(strip=True)
        return ""
    
    def _extract_publication_date(self, article: Tag) -> datetime:
        """Extract the publication date from the article XML."""
        # Try to get the publication date
        pub_date = article.find("pubdate")
        if pub_date and isinstance(pub_date, Tag):
            year = pub_date.find("year")
            month = pub_date.find("month")
            day = pub_date.find("day")
            
            if year and isinstance(year, Tag):
                year_val = int(year.get_text())
                month_val = int(month.get_text()) if month and isinstance(month, Tag) else 1
                day_val = int(day.get_text()) if day and isinstance(day, Tag) else 1
                return datetime(year_val, month_val, day_val)
        
        # Fallback to current date if no date found
        return datetime.now()
    
    def _extract_authors(self, article: Tag) -> List[Author]:
        """Extract authors and their affiliations from the article XML."""
        authors = []
        author_list = article.find("authorlist")
        
        if not author_list or not isinstance(author_list, Tag):
            return authors
        
        for author_elem in author_list.find_all("author"):
            if not isinstance(author_elem, Tag):
                continue
            author_name = self._extract_author_name(author_elem)
            if not author_name:
                continue
            
            email = self._extract_author_email(author_elem)
            affiliations = self._extract_author_affiliations(author_elem)
            is_corresponding = self._is_corresponding_author(author_elem)
            
            author = Author(
                name=author_name,
                email=email,
                affiliations=affiliations,
                is_corresponding=is_corresponding
            )
            authors.append(author)
        
        return authors
    
    def _extract_author_name(self, author_elem: Tag) -> str:
        """Extract the author's name."""
        last_name = author_elem.find("lastname")
        fore_name = author_elem.find("forename")
        
        if last_name and fore_name:
            return f"{fore_name.get_text()} {last_name.get_text()}"
        elif last_name:
            return last_name.get_text()
        elif fore_name:
            return fore_name.get_text()
        
        return ""
    
    def _extract_author_email(self, author_elem: Tag) -> Optional[str]:
        """Extract the author's email address."""
        # Email is typically not in the XML, would need additional API calls
        # For now, return None
        return None
    
    def _extract_author_affiliations(self, author_elem: Tag) -> List[Affiliation]:
        """Extract the author's institutional affiliations."""
        affiliations = []
        
        # Look for affiliation information
        affiliation_elem = author_elem.find("affiliationinfo")
        if affiliation_elem:
            aff_text = affiliation_elem.get_text(strip=True)
            if aff_text:
                affiliation = self._parse_affiliation(aff_text)
                affiliations.append(affiliation)
        
        # Also check for collective name (institution)
        collective_name = author_elem.find("collectivename")
        if collective_name:
            aff_text = collective_name.get_text(strip=True)
            if aff_text:
                affiliation = self._parse_affiliation(aff_text)
                affiliations.append(affiliation)
        
        return affiliations
    
    def _parse_affiliation(self, affiliation_text: str) -> Affiliation:
        """Parse affiliation text to determine if it's academic or biotech/pharma."""
        affiliation_lower = affiliation_text.lower()
        
        # Check if it's academic
        is_academic = any(keyword in affiliation_lower for keyword in self.ACADEMIC_KEYWORDS)
        
        # Check if it's biotech/pharma
        is_biotech_pharma = any(keyword in affiliation_lower for keyword in self.BIOTECH_PHARMA_KEYWORDS)
        
        return Affiliation(
            name=affiliation_text,
            is_academic=is_academic,
            is_biotech_pharma=is_biotech_pharma
        )
    
    def _is_corresponding_author(self, author_elem: Tag) -> bool:
        """Check if the author is the corresponding author."""
        # This information is not directly available in the XML
        # Would need additional processing or API calls
        return False
    
    def fetch_papers_with_non_academic_authors(
        self, 
        query: str, 
        max_results: int = 100
    ) -> List[Paper]:
        """Fetch papers and filter for those with non-academic authors.
        
        Args:
            query: Search query string
            max_results: Maximum number of results to process
            
        Returns:
            List of papers with non-academic authors
        """
        self.logger.info(f"Fetching papers with non-academic authors for query: {query}")
        
        # Search for papers
        pubmed_ids = self.search_papers(query, max_results)
        if not pubmed_ids:
            return []
        
        papers_with_non_academic = []
        
        for pubmed_id in pubmed_ids:
            # Add delay to respect API rate limits
            time.sleep(0.1)
            
            paper = self.fetch_paper_details(pubmed_id)
            if paper and paper.has_non_academic_authors:
                papers_with_non_academic.append(paper)
                self.logger.debug(f"Found paper with non-academic authors: {paper.pubmed_id}")
        
        self.logger.info(f"Found {len(papers_with_non_academic)} papers with non-academic authors")
        return papers_with_non_academic
    
    def export_to_csv(self, papers: List[Paper], output_file: str) -> None:
        """Export papers to CSV format.
        
        Args:
            papers: List of papers to export
            output_file: Output file path
        """
        try:
            import pandas as pd
        except ImportError:
            self.logger.error("pandas is required for CSV export. Install with: pip install pandas")
            return
        
        data = []
        for paper in papers:
            # Get non-academic authors
            non_academic_authors = paper.non_academic_authors
            author_names = "; ".join([author.name for author in non_academic_authors])
            
            # Get company affiliations
            affiliations = []
            for author in non_academic_authors:
                for affiliation in author.biotech_pharma_affiliations:
                    affiliations.append(affiliation.name)
            company_affiliations = "; ".join(set(affiliations))
            
            data.append({
                "PubmedID": paper.pubmed_id,
                "Title": paper.title,
                "Publication Date": paper.publication_date.strftime("%Y-%m-%d"),
                "Non-academic Author(s)": author_names,
                "Company Affiliation(s)": company_affiliations,
                "Corresponding Author Email": paper.corresponding_author_email or ""
            })
        
        df = pd.DataFrame(data)
        df.to_csv(output_file, index=False)
        self.logger.info(f"Exported {len(papers)} papers to {output_file}")
