"""Unit tests for CLI module."""

import pytest
from unittest.mock import patch, Mock
from pubmed_fetcher.cli import create_parser, main


class TestCLI:
    """Test cases for CLI functionality."""
    
    def test_create_parser(self):
        """Test argument parser creation."""
        parser = create_parser()
        
        # Test that required argument exists
        assert parser._option_string_actions.get('query') is None  # It's a positional argument
        
        # Test that optional arguments exist
        assert '--file' in parser._option_string_actions
        assert '--debug' in parser._option_string_actions
        assert '--max-results' in parser._option_string_actions
        assert '--help' in parser._option_string_actions
    
    def test_parser_help(self):
        """Test that parser shows help."""
        parser = create_parser()
        help_text = parser.format_help()
        
        assert "Fetch PubMed papers" in help_text
        assert "Search query for PubMed papers" in help_text
        assert "--file" in help_text
        assert "--debug" in help_text
    
    @patch('pubmed_fetcher.cli.PubMedFetcher')
    def test_main_success(self, mock_fetcher_class):
        """Test successful CLI execution."""
        # Mock the fetcher
        mock_fetcher = Mock()
        mock_fetcher_class.return_value = mock_fetcher
        mock_fetcher.fetch_papers_with_non_academic_authors.return_value = []
        
        # Test with basic arguments
        args = ["test query"]
        result = main(args)
        
        assert result == 0
        mock_fetcher_class.assert_called_once_with(debug=False)
        mock_fetcher.fetch_papers_with_non_academic_authors.assert_called_once_with(
            query="test query",
            max_results=100
        )
    
    @patch('pubmed_fetcher.cli.PubMedFetcher')
    def test_main_with_debug(self, mock_fetcher_class):
        """Test CLI execution with debug flag."""
        mock_fetcher = Mock()
        mock_fetcher_class.return_value = mock_fetcher
        mock_fetcher.fetch_papers_with_non_academic_authors.return_value = []
        
        args = ["test query", "--debug"]
        result = main(args)
        
        assert result == 0
        mock_fetcher_class.assert_called_once_with(debug=True)
    
    @patch('pubmed_fetcher.cli.PubMedFetcher')
    def test_main_with_custom_file(self, mock_fetcher_class):
        """Test CLI execution with custom output file."""
        mock_fetcher = Mock()
        mock_fetcher_class.return_value = mock_fetcher
        mock_fetcher.fetch_papers_with_non_academic_authors.return_value = []
        
        args = ["test query", "--file", "custom_output.csv"]
        result = main(args)
        
        assert result == 0
        mock_fetcher.export_to_csv.assert_called_once_with([], "custom_output.csv")
    
    @patch('pubmed_fetcher.cli.PubMedFetcher')
    def test_main_with_max_results(self, mock_fetcher_class):
        """Test CLI execution with max results limit."""
        mock_fetcher = Mock()
        mock_fetcher_class.return_value = mock_fetcher
        mock_fetcher.fetch_papers_with_non_academic_authors.return_value = []
        
        args = ["test query", "--max-results", "50"]
        result = main(args)
        
        assert result == 0
        mock_fetcher.fetch_papers_with_non_academic_authors.assert_called_once_with(
            query="test query",
            max_results=50
        )
    
    @patch('pubmed_fetcher.cli.PubMedFetcher')
    def test_main_with_papers_found(self, mock_fetcher_class):
        """Test CLI execution when papers are found."""
        from pubmed_fetcher.models import Paper, Author, Affiliation
        from datetime import datetime
        
        # Create mock papers
        authors = [Author("Test Author", None, [Affiliation("Test Corp", False, True)], False)]
        papers = [
            Paper("12345", "Test Paper", datetime.now(), authors)
        ]
        
        mock_fetcher = Mock()
        mock_fetcher_class.return_value = mock_fetcher
        mock_fetcher.fetch_papers_with_non_academic_authors.return_value = papers
        
        args = ["test query"]
        result = main(args)
        
        assert result == 0
        mock_fetcher.export_to_csv.assert_called_once_with(papers, "papers_with_non_academic_authors.csv")
    
    @patch('pubmed_fetcher.cli.PubMedFetcher')
    def test_main_exception_handling(self, mock_fetcher_class):
        """Test CLI exception handling."""
        mock_fetcher = Mock()
        mock_fetcher_class.return_value = mock_fetcher
        mock_fetcher.fetch_papers_with_non_academic_authors.side_effect = Exception("Test error")
        
        args = ["test query"]
        result = main(args)
        
        assert result == 1
    
    @patch('pubmed_fetcher.cli.PubMedFetcher')
    def test_main_keyboard_interrupt(self, mock_fetcher_class):
        """Test CLI keyboard interrupt handling."""
        mock_fetcher = Mock()
        mock_fetcher_class.return_value = mock_fetcher
        mock_fetcher.fetch_papers_with_non_academic_authors.side_effect = KeyboardInterrupt()
        
        args = ["test query"]
        result = main(args)
        
        assert result == 1 