"""Unit tests for PubMedFetcher."""

import pytest
from unittest.mock import Mock, patch
from datetime import datetime
from pubmed_fetcher.fetcher import PubMedFetcher
from pubmed_fetcher.models import Paper, Author, Affiliation


class TestPubMedFetcher:
    """Test cases for PubMedFetcher class."""
    
    def test_init(self):
        """Test PubMedFetcher initialization."""
        fetcher = PubMedFetcher(debug=True)
        assert fetcher.debug is True
        assert fetcher.logger is not None
    
    def test_parse_affiliation_academic(self):
        """Test parsing academic affiliations."""
        fetcher = PubMedFetcher()
        
        # Test academic institution
        affiliation = fetcher._parse_affiliation("Harvard University Medical School")
        assert affiliation.name == "Harvard University Medical School"
        assert affiliation.is_academic is True
        assert affiliation.is_biotech_pharma is False
    
    def test_parse_affiliation_biotech(self):
        """Test parsing biotech/pharma affiliations."""
        fetcher = PubMedFetcher()
        
        # Test biotech company
        affiliation = fetcher._parse_affiliation("Biotech Therapeutics Inc")
        assert affiliation.name == "Biotech Therapeutics Inc"
        assert affiliation.is_academic is False
        assert affiliation.is_biotech_pharma is True
    
    def test_parse_affiliation_neutral(self):
        """Test parsing neutral affiliations."""
        fetcher = PubMedFetcher()
        
        # Test neutral institution
        affiliation = fetcher._parse_affiliation("Government Research Institute")
        assert affiliation.name == "Government Research Institute"
        assert affiliation.is_academic is False
        assert affiliation.is_biotech_pharma is False
    
    @patch('pubmed_fetcher.fetcher.requests.get')
    def test_search_papers_success(self, mock_get):
        """Test successful paper search."""
        # Mock successful response
        mock_response = Mock()
        mock_response.json.return_value = {
            "esearchresult": {
                "idlist": ["12345", "67890", "11111"]
            }
        }
        mock_response.raise_for_status.return_value = None
        mock_get.return_value = mock_response
        
        fetcher = PubMedFetcher()
        results = fetcher.search_papers("cancer immunotherapy")
        
        assert results == ["12345", "67890", "11111"]
        mock_get.assert_called_once()
    
    @patch('pubmed_fetcher.fetcher.requests.get')
    def test_search_papers_error(self, mock_get):
        """Test paper search with error."""
        # Mock error response
        mock_get.side_effect = Exception("Network error")
        
        fetcher = PubMedFetcher()
        results = fetcher.search_papers("cancer immunotherapy")
        
        assert results == []
    
    @patch('pubmed_fetcher.fetcher.requests.get')
    def test_fetch_paper_details_success(self, mock_get):
        """Test successful paper details fetch."""
        # Mock XML response
        xml_content = """
        <pubmedarticle>
            <medlinecitation>
                <article>
                    <articletitle>Test Paper Title</articletitle>
                    <authorlist>
                        <author>
                            <lastname>Doe</lastname>
                            <forename>John</forename>
                            <affiliationinfo>
                                <affiliation>Harvard University</affiliation>
                            </affiliationinfo>
                        </author>
                    </authorlist>
                </article>
            </medlinecitation>
            <pubmeddata>
                <history>
                    <pubdate>
                        <year>2023</year>
                        <month>1</month>
                        <day>15</day>
                    </pubdate>
                </history>
            </pubmeddata>
        </pubmedarticle>
        """
        
        mock_response = Mock()
        mock_response.content = xml_content.encode()
        mock_response.raise_for_status.return_value = None
        mock_get.return_value = mock_response
        
        fetcher = PubMedFetcher()
        paper = fetcher.fetch_paper_details("12345")
        
        assert paper is not None
        assert paper.pubmed_id == "12345"
        assert paper.title == "Test Paper Title"
        assert len(paper.authors) == 1
        assert paper.authors[0].name == "John Doe"
    
    @patch('pubmed_fetcher.fetcher.requests.get')
    def test_fetch_paper_details_no_article(self, mock_get):
        """Test paper details fetch with no article found."""
        # Mock empty XML response
        mock_response = Mock()
        mock_response.content = "<pubmedarticleset></pubmedarticleset>".encode()
        mock_response.raise_for_status.return_value = None
        mock_get.return_value = mock_response
        
        fetcher = PubMedFetcher()
        paper = fetcher.fetch_paper_details("12345")
        
        assert paper is None
    
    def test_extract_author_name_full(self):
        """Test extracting full author name."""
        fetcher = PubMedFetcher()
        
        # Mock author element with full name
        mock_author = Mock()
        mock_author.find.side_effect = lambda tag: {
            "LastName": Mock(get_text=lambda: "Doe"),
            "ForeName": Mock(get_text=lambda: "John")
        }.get(tag)
        
        name = fetcher._extract_author_name(mock_author)
        assert name == "John Doe"
    
    def test_extract_author_name_last_only(self):
        """Test extracting author name with only last name."""
        fetcher = PubMedFetcher()
        
        # Mock author element with only last name
        mock_author = Mock()
        mock_author.find.side_effect = lambda tag: {
            "LastName": Mock(get_text=lambda: "Doe"),
            "ForeName": None
        }.get(tag)
        
        name = fetcher._extract_author_name(mock_author)
        assert name == "Doe"
    
    def test_extract_author_affiliations(self):
        """Test extracting author affiliations."""
        fetcher = PubMedFetcher()
        
        # Mock author element with affiliations
        mock_author = Mock()
        mock_affiliation = Mock()
        mock_affiliation.get_text.return_value = "Biotech Corp"
        mock_author.find.return_value = mock_affiliation
        
        affiliations = fetcher._extract_author_affiliations(mock_author)
        
        assert len(affiliations) == 1
        assert affiliations[0].name == "Biotech Corp"
        assert affiliations[0].is_biotech_pharma is True
    
    @patch('pubmed_fetcher.fetcher.requests.get')
    def test_fetch_papers_with_non_academic_authors(self, mock_get):
        """Test fetching papers with non-academic authors."""
        # Mock search response
        mock_search_response = Mock()
        mock_search_response.json.return_value = {
            "esearchresult": {"idlist": ["12345", "67890"]}
        }
        mock_search_response.raise_for_status.return_value = None
        
        # Mock paper details response
        xml_content = """
        <pubmedarticle>
            <medlinecitation>
                <article>
                    <articletitle>Test Paper</articletitle>
                    <authorlist>
                        <author>
                            <lastname>Doe</lastname>
                            <forename>John</forename>
                            <affiliationinfo>
                                <affiliation>Biotech Corp</affiliation>
                            </affiliationinfo>
                        </author>
                    </authorlist>
                </article>
            </medlinecitation>
            <pubmeddata>
                <history>
                    <pubdate>
                        <year>2023</year>
                        <month>1</month>
                        <day>1</day>
                    </pubdate>
                </history>
            </pubmeddata>
        </pubmedarticle>
        """
        
        mock_details_response = Mock()
        mock_details_response.content = xml_content.encode()
        mock_details_response.raise_for_status.return_value = None
        
        # Configure mock to return different responses for search and details
        mock_get.side_effect = [mock_search_response, mock_details_response, mock_details_response]
        
        fetcher = PubMedFetcher()
        papers = fetcher.fetch_papers_with_non_academic_authors("test query")
        
        assert len(papers) == 2
        for paper in papers:
            assert paper.has_non_academic_authors is True
    
    @patch('pubmed_fetcher.fetcher.pd.DataFrame')
    @patch('pubmed_fetcher.fetcher.pd')
    def test_export_to_csv(self, mock_pd, mock_df):
        """Test CSV export functionality."""
        # Create test papers
        authors = [
            Author("John Doe", "john@example.com", [
                Affiliation("Biotech Corp", False, True)
            ], False)
        ]
        
        papers = [
            Paper(
                pubmed_id="12345",
                title="Test Paper",
                publication_date=datetime(2023, 1, 1),
                authors=authors
            )
        ]
        
        fetcher = PubMedFetcher()
        fetcher.export_to_csv(papers, "test.csv")
        
        # Verify pandas was called correctly
        mock_pd.DataFrame.assert_called_once()
        mock_df_instance = mock_pd.DataFrame.return_value
        mock_df_instance.to_csv.assert_called_once_with("test.csv", index=False) 