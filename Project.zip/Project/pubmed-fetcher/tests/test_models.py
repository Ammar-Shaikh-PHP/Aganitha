"""Unit tests for data models."""

import pytest
from datetime import datetime
from pubmed_fetcher.models import Paper, Author, Affiliation


class TestAffiliation:
    """Test cases for Affiliation model."""
    
    def test_valid_affiliation(self):
        """Test creating a valid affiliation."""
        affiliation = Affiliation(
            name="Harvard University",
            is_academic=True,
            is_biotech_pharma=False
        )
        assert affiliation.name == "Harvard University"
        assert affiliation.is_academic is True
        assert affiliation.is_biotech_pharma is False
    
    def test_empty_name_raises_error(self):
        """Test that empty name raises ValueError."""
        with pytest.raises(ValueError, match="Affiliation name cannot be empty"):
            Affiliation(name="", is_academic=True, is_biotech_pharma=False)
    
    def test_whitespace_name_raises_error(self):
        """Test that whitespace-only name raises ValueError."""
        with pytest.raises(ValueError, match="Affiliation name cannot be empty"):
            Affiliation(name="   ", is_academic=True, is_biotech_pharma=False)


class TestAuthor:
    """Test cases for Author model."""
    
    def test_valid_author(self):
        """Test creating a valid author."""
        affiliations = [
            Affiliation("Harvard University", True, False),
            Affiliation("Biotech Corp", False, True)
        ]
        
        author = Author(
            name="John Doe",
            email="john.doe@example.com",
            affiliations=affiliations,
            is_corresponding=True
        )
        
        assert author.name == "John Doe"
        assert author.email == "john.doe@example.com"
        assert len(author.affiliations) == 2
        assert author.is_corresponding is True
    
    def test_empty_name_raises_error(self):
        """Test that empty name raises ValueError."""
        with pytest.raises(ValueError, match="Author name cannot be empty"):
            Author(name="", email=None, affiliations=[], is_corresponding=False)
    
    def test_has_non_academic_affiliation(self):
        """Test has_non_academic_affiliation property."""
        # Author with only academic affiliations
        academic_author = Author(
            name="Academic Author",
            email=None,
            affiliations=[Affiliation("Harvard University", True, False)],
            is_corresponding=False
        )
        assert academic_author.has_non_academic_affiliation is False
        
        # Author with non-academic affiliation
        non_academic_author = Author(
            name="Non-academic Author",
            email=None,
            affiliations=[Affiliation("Biotech Corp", False, True)],
            is_corresponding=False
        )
        assert non_academic_author.has_non_academic_affiliation is True
    
    def test_has_biotech_pharma_affiliation(self):
        """Test has_biotech_pharma_affiliation property."""
        # Author with biotech/pharma affiliation
        biotech_author = Author(
            name="Biotech Author",
            email=None,
            affiliations=[Affiliation("Biotech Corp", False, True)],
            is_corresponding=False
        )
        assert biotech_author.has_biotech_pharma_affiliation is True
        
        # Author without biotech/pharma affiliation
        non_biotech_author = Author(
            name="Non-biotech Author",
            email=None,
            affiliations=[Affiliation("Consulting Firm", False, False)],
            is_corresponding=False
        )
        assert non_biotech_author.has_biotech_pharma_affiliation is False
    
    def test_non_academic_affiliations(self):
        """Test non_academic_affiliations property."""
        author = Author(
            name="Mixed Author",
            email=None,
            affiliations=[
                Affiliation("Harvard University", True, False),
                Affiliation("Biotech Corp", False, True),
                Affiliation("Consulting Firm", False, False)
            ],
            is_corresponding=False
        )
        
        non_academic = author.non_academic_affiliations
        assert len(non_academic) == 2
        assert any(aff.name == "Biotech Corp" for aff in non_academic)
        assert any(aff.name == "Consulting Firm" for aff in non_academic)
    
    def test_biotech_pharma_affiliations(self):
        """Test biotech_pharma_affiliations property."""
        author = Author(
            name="Mixed Author",
            email=None,
            affiliations=[
                Affiliation("Harvard University", True, False),
                Affiliation("Biotech Corp", False, True),
                Affiliation("Pharma Inc", False, True)
            ],
            is_corresponding=False
        )
        
        biotech_pharma = author.biotech_pharma_affiliations
        assert len(biotech_pharma) == 2
        assert any(aff.name == "Biotech Corp" for aff in biotech_pharma)
        assert any(aff.name == "Pharma Inc" for aff in biotech_pharma)


class TestPaper:
    """Test cases for Paper model."""
    
    def test_valid_paper(self):
        """Test creating a valid paper."""
        authors = [
            Author("John Doe", "john@example.com", [], False),
            Author("Jane Smith", "jane@example.com", [], True)
        ]
        
        paper = Paper(
            pubmed_id="12345",
            title="Test Paper",
            publication_date=datetime(2023, 1, 1),
            authors=authors
        )
        
        assert paper.pubmed_id == "12345"
        assert paper.title == "Test Paper"
        assert paper.publication_date == datetime(2023, 1, 1)
        assert len(paper.authors) == 2
    
    def test_empty_pubmed_id_raises_error(self):
        """Test that empty PubMed ID raises ValueError."""
        with pytest.raises(ValueError, match="PubMed ID cannot be empty"):
            Paper(
                pubmed_id="",
                title="Test Paper",
                publication_date=datetime.now(),
                authors=[]
            )
    
    def test_empty_title_raises_error(self):
        """Test that empty title raises ValueError."""
        with pytest.raises(ValueError, match="Title cannot be empty"):
            Paper(
                pubmed_id="12345",
                title="",
                publication_date=datetime.now(),
                authors=[]
            )
    
    def test_has_non_academic_authors(self):
        """Test has_non_academic_authors property."""
        # Paper with only academic authors
        academic_authors = [
            Author("Academic Author", None, [Affiliation("Harvard", True, False)], False)
        ]
        academic_paper = Paper(
            pubmed_id="12345",
            title="Academic Paper",
            publication_date=datetime.now(),
            authors=academic_authors
        )
        assert academic_paper.has_non_academic_authors is False
        
        # Paper with non-academic authors
        mixed_authors = [
            Author("Academic Author", None, [Affiliation("Harvard", True, False)], False),
            Author("Non-academic Author", None, [Affiliation("Biotech Corp", False, True)], False)
        ]
        mixed_paper = Paper(
            pubmed_id="12346",
            title="Mixed Paper",
            publication_date=datetime.now(),
            authors=mixed_authors
        )
        assert mixed_paper.has_non_academic_authors is True
    
    def test_has_biotech_pharma_authors(self):
        """Test has_biotech_pharma_authors property."""
        # Paper with biotech/pharma authors
        biotech_authors = [
            Author("Biotech Author", None, [Affiliation("Biotech Corp", False, True)], False)
        ]
        biotech_paper = Paper(
            pubmed_id="12347",
            title="Biotech Paper",
            publication_date=datetime.now(),
            authors=biotech_authors
        )
        assert biotech_paper.has_biotech_pharma_authors is True
    
    def test_non_academic_authors(self):
        """Test non_academic_authors property."""
        authors = [
            Author("Academic Author", None, [Affiliation("Harvard", True, False)], False),
            Author("Non-academic Author", None, [Affiliation("Biotech Corp", False, True)], False),
            Author("Another Non-academic", None, [Affiliation("Consulting", False, False)], False)
        ]
        paper = Paper(
            pubmed_id="12348",
            title="Test Paper",
            publication_date=datetime.now(),
            authors=authors
        )
        
        non_academic = paper.non_academic_authors
        assert len(non_academic) == 2
        assert any(author.name == "Non-academic Author" for author in non_academic)
        assert any(author.name == "Another Non-academic" for author in non_academic)
    
    def test_corresponding_author(self):
        """Test corresponding_author property."""
        authors = [
            Author("First Author", "first@example.com", [], False),
            Author("Corresponding Author", "corresponding@example.com", [], True),
            Author("Last Author", "last@example.com", [], False)
        ]
        paper = Paper(
            pubmed_id="12349",
            title="Test Paper",
            publication_date=datetime.now(),
            authors=authors
        )
        
        corresponding = paper.corresponding_author
        assert corresponding is not None
        assert corresponding.name == "Corresponding Author"
        assert corresponding.email == "corresponding@example.com"
    
    def test_corresponding_author_email(self):
        """Test corresponding_author_email property."""
        # Paper with corresponding author
        authors_with_corresponding = [
            Author("Author 1", "author1@example.com", [], False),
            Author("Corresponding Author", "corresponding@example.com", [], True)
        ]
        paper_with_corresponding = Paper(
            pubmed_id="12350",
            title="Test Paper",
            publication_date=datetime.now(),
            authors=authors_with_corresponding
        )
        assert paper_with_corresponding.corresponding_author_email == "corresponding@example.com"
        
        # Paper without corresponding author
        authors_without_corresponding = [
            Author("Author 1", "author1@example.com", [], False),
            Author("Author 2", "author2@example.com", [], False)
        ]
        paper_without_corresponding = Paper(
            pubmed_id="12351",
            title="Test Paper",
            publication_date=datetime.now(),
            authors=authors_without_corresponding
        )
        assert paper_without_corresponding.corresponding_author_email is None 