#!/usr/bin/env python3
"""Example usage of PubMed Fetcher."""

from pubmed_fetcher import PubMedFetcher


def main():
    """Example of using PubMedFetcher to find papers with non-academic authors."""
    
    # Initialize the fetcher with debug logging
    fetcher = PubMedFetcher(debug=True)
    
    # Search for papers related to cancer immunotherapy
    print("Searching for papers with non-academic authors...")
    papers = fetcher.fetch_papers_with_non_academic_authors(
        query="cancer immunotherapy",
        max_results=10
    )
    
    if not papers:
        print("No papers found with non-academic authors.")
        return
    
    print(f"\nFound {len(papers)} papers with non-academic authors:")
    print("=" * 80)
    
    for i, paper in enumerate(papers, 1):
        print(f"\n{i}. PMID: {paper.pubmed_id}")
        print(f"   Title: {paper.title}")
        print(f"   Publication Date: {paper.publication_date.strftime('%Y-%m-%d')}")
        
        # Show non-academic authors
        if paper.non_academic_authors:
            print("   Non-academic Authors:")
            for author in paper.non_academic_authors:
                print(f"     - {author.name}")
                for affiliation in author.biotech_pharma_affiliations:
                    print(f"       Affiliation: {affiliation.name}")
        
        # Show corresponding author email if available
        if paper.corresponding_author_email:
            print(f"   Corresponding Author Email: {paper.corresponding_author_email}")
    
    # Export to CSV
    output_file = "example_results.csv"
    fetcher.export_to_csv(papers, output_file)
    print(f"\nResults exported to {output_file}")


if __name__ == "__main__":
    main() 